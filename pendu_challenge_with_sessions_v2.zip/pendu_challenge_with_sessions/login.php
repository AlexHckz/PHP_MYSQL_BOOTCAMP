<?php

//on demarre la session
session_start();

//quand la personne est connectée 
